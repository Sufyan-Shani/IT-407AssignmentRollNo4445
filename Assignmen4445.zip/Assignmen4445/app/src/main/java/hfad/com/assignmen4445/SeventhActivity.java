package hfad.com.assignmen4445;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SeventhActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seventh);
    }
}