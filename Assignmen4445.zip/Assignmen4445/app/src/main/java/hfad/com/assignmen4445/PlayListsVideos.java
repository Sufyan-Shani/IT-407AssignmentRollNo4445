package hfad.com.assignmen4445;

public class PlayListsVideos {
    int picture;
    String text;
    int picIcon;

    public PlayListsVideos(int picture, String text) {
        this.picture = picture;
        this.text = text;
    }

    public int getPicture() {
        return picture;
    }

    public void setPicture(int picture) {
        this.picture = picture;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
